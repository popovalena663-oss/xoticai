# XoticAI Personal

A minimal private personal AI studio starter.

## Run locally
1. Install Node.js 20+.
2. Extract the folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open http://localhost:3000

The login in this starter is a local UI lock, not production authentication. The generator is demo-only. To publish a truly private site, add real authentication and connect an AI provider/GPU.